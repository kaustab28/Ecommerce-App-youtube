USE DATABASE MERIDIAN_FRAUD_DB;

USE SCHEMA KNOWLEDGE;

TRUNCATE TABLE KNOWLEDGE.FRAUD_PATTERN_DOCS;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-001',
  'P001_card_testing_bustout.md',
  'Card Testing Followed by Bust-Out',
  'Card-Not-Present Fraud',
  'HIGH',
  $$ # Fraud Pattern P-001: Card Testing Followed by Bust-Out

**Pattern ID:** P-001
**Category:** Card-Not-Present (CNP) Fraud
**Severity:** HIGH
**Last reviewed:** 2026-03-15

## Signature
Fraudsters who have purchased or stolen a batch of card numbers will first verify which cards are still active before attempting any large-value transaction. The verification phase is characterized by a sequence of micro-charges at low-friction merchants. Once a card responds with an authorization, the same card is hit with a large charge within minutes.

## Detection signals
- 3 or more transactions on the same PAN within a 15-minute window
- Individual amounts under USD 10, often ending in .99 or .49
- Merchants in **MCC 5815** (digital downloads), **MCC 5816** (game vouchers), or **MCC 5967** (direct marketing — outbound telemarketing)
- Merchant in a different country than the cardholder's billing country
- IP address from a hosting/VPN range or a country mismatched with the cardholder
- Device ID not previously seen on the account
- All transactions in card-not-present (CNP) channel
- A final transaction with amount > 50x the average of the testing burst

## Typical merchant clusters
- Cyprus, Malta, Isle of Man, and Gibraltar registered digital goods merchants
- Newly registered merchants (< 12 months) with elevated chargeback rates
- Gaming top-up resellers in Southeast Asia

## Recommended action when matched
1. Decline the largest pending authorization
2. Freeze the card and issue a replacement
3. Reverse-charge all successful test transactions
4. Notify the cardholder via the registered mobile number (not email — assume email is compromised)
5. Escalate to the fraud analyst queue with priority FRAUD-HIGH

## Reference cases
- FC2025-0411 — confirmed loss USD 3,450
- FC2026-0208 — confirmed loss USD 2,890

## False-positive considerations
A legitimate customer trialing a new subscription service may produce two or three small charges. The defining marker is the **bust-out transaction** within the same 30-minute window. Without the large follow-on, treat as low-priority review.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-002',
  'P002_geographic_anomaly.md',
  'Geographic Anomaly / Impossible Travel',
  'Counterfeit / Cloned Card Fraud',
  'HIGH',
  $$ # Fraud Pattern P-002: Geographic Anomaly / Impossible Travel

**Pattern ID:** P-002
**Category:** Counterfeit / Cloned Card Fraud
**Severity:** HIGH
**Last reviewed:** 2026-02-20

## Signature
A card is used in a location physically incompatible with the cardholder's verified position at the same time, or with their established travel pattern. This typically indicates the card has been cloned (magstripe skimmed or e-commerce credentials leaked) and is being used by a separate party while the customer still possesses the physical card.

## Detection signals
- Transaction country differs from cardholder's home country
- No travel signal in the prior 14 days (no airline, lodging, or rideshare bookings)
- Transaction occurs during cardholder's typical sleeping hours in their home time zone
- IP geolocation places the device in a third country (often Eastern Europe, Southeast Asia, or West Africa proxy locations)
- Single high-value transaction rather than a sequence
- Merchant categories favored: jewelry (MCC 5944), electronics (MCC 5732), forex (MCC 4829), gold dealers

## Heightening factors
- Card was recently used at a known compromised merchant
- A "card present" flag on a foreign POS while the cardholder's device is geolocated at home
- Customer has no prior history of international transactions

## Recommended action when matched
1. Hard decline if pending; chargeback recall if already settled
2. Block the card immediately
3. Verify cardholder location via app push, then SMS, then phone
4. If verified fraud: open a case, file SAFE (Suspicious Activity File Exchange) report, request merchant transaction record
5. Issue a replacement card

## Reference cases
- FC2025-0529 — Kuala Lumpur jewelry while cardholder was in Boston — USD 8,200
- FC2026-0303 — Bangkok jewelry while cardholder was in Chicago — USD 4,850

## False-positive considerations
Frequent international travelers (segment tier PLATINUM with > 4 foreign trips per year) often produce this signal legitimately. Look for corroborating travel evidence in the past 14 days. If the customer's prior month includes an airline transaction whose destination matches the current country, suppress alert unless other signals (new device, proxy IP, atypical merchant) are also present.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-003',
  'P003_account_takeover.md',
  'Account Takeover',
  'Credential / Session Compromise',
  'HIGH',
  $$ # Fraud Pattern P-003: Account Takeover (ATO)

**Pattern ID:** P-003
**Category:** Credential / Session Compromise
**Severity:** HIGH
**Last reviewed:** 2026-04-02

## Signature
An attacker gains control of the customer's online banking or wallet credentials (via phishing, credential stuffing, SIM swap, or malware) and uses the legitimate card credentials from a new device. Unlike cloning, the transaction routes through the customer's own account but originates from an attacker-controlled session.

## Detection signals
- Login from a device ID never seen on the account
- Login or transaction during cardholder's typical off-hours (especially 02:00 - 05:00 local time)
- Within 24 hours of any of: password reset, email change, phone number change, new device enrollment, SIM swap notice
- High-value purchase at a merchant the cardholder has never transacted with
- Merchant categories favored: luxury watches and jewelry (MCC 5944), electronics (MCC 5732), money transfer (MCC 4829)
- Shipping address differs from the billing address
- Multiple transactions clustered in a single session, often at distinct merchants

## Recommended action when matched
1. Decline the pending authorization
2. Block all sessions across the customer's accounts
3. Force re-authentication via out-of-band channel (registered phone callback, not SMS)
4. Notify the cardholder by voice call, not email or SMS, since both may be compromised
5. Open ATO investigation case in the fraud-ops queue

## Reference cases
- FC2025-0712 — overnight jewelry purchases from new Windows device — USD 5,670
- FC2026-0421 — luxury watch after ignored SIM swap notice — USD 3,200

## False-positive considerations
A customer who legitimately replaces their phone or laptop will produce a new-device login. The defining marker is the **combination** of new device + off-hours + high-value at unfamiliar merchant. Any one of these alone is not sufficient. The customer-initiated device enrollment (which produces a confirmation event in our auth logs) should suppress the device-novelty signal for 7 days.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-004',
  'P004_crypto_scam.md',
  'Authorized Push Payment to Crypto',
  'Authorized Push Payment Fraud',
  'MEDIUM-HIGH',
  $$ # Fraud Pattern P-004: Authorized Push Payment to Crypto (Scam Victim)

**Pattern ID:** P-004
**Category:** Authorized Push Payment Fraud (Scam Victim)
**Severity:** MEDIUM-HIGH
**Last reviewed:** 2026-04-25

## Signature
The cardholder themselves initiates a transaction to a cryptocurrency exchange or money-transfer merchant, but is doing so under the influence of a third-party scam (investment scam, romance scam, impersonation scam, employment scam). The transaction is **authenticated by the genuine customer** which makes it technically authorized, but the customer is a victim of social engineering.

## Detection signals
- First-ever transaction to a cryptocurrency merchant (MCC 6051) or money transfer service (MCC 4829)
- Transaction amount is a round number (e.g. USD 2,000 / 5,000 / 10,000)
- Customer demographic profile not typically associated with crypto investing (e.g. retiree, very young new-account holder)
- Funds transferred to the customer's account from a savings or external source in the 48 hours prior
- Multiple smaller transactions over days rather than a single large one
- Customer attempted the same transaction earlier and it was declined for limit reasons

## Recommended action when matched
1. **Do not auto-decline** — the customer authorized the transaction
2. Insert a friction step in the payment flow: a scam-awareness interstitial in the mobile app
3. Outbound call from the fraud team within 1 hour of the transaction
4. Provide the customer with reporting resources (FTC / Action Fraud / local equivalent)
5. Log a scam-victim flag on the account; subsequent crypto transactions should re-trigger the interstitial for 90 days

## Reference cases
- FC2026-0505 — USD 6,500 to crypto exchange after a romance scam

## False-positive considerations
Legitimate crypto investing is increasingly common, especially among customers aged 25-45. The defining marker is the **combination** of: first-ever crypto, atypical demographic, recent inbound funding to the source account, and round-number amount. Two or fewer signals = legitimate trader. Three or more = probable scam victim. Treat with empathy regardless of outcome — these customers are victims, not perpetrators.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-005',
  'P005_frequent_traveler_suppression.md',
  'Frequent Traveler False Positive Suppression',
  'False-Positive Suppression Rule',
  'N/A',
  $$ # Fraud Pattern P-005: Frequent Traveler — False Positive Suppression

**Pattern ID:** P-005
**Category:** False-Positive Suppression Rule
**Severity:** N/A (suppression rule)
**Last reviewed:** 2026-01-30

## Purpose
This document describes the corroborating evidence required to suppress geographic-anomaly alerts (Pattern P-002) when the cardholder is on legitimate international travel. Approximately 38% of geographic-anomaly alerts in our portfolio are false positives driven by frequent travelers, so accurate suppression is essential to reduce review queue load.

## Suppression criteria — all of the following must hold

### 1. Established travel pattern
The customer's tier is GOLD or PLATINUM **and** has at least 3 prior cross-border transactions in the past 12 months.

### 2. Corroborating travel signal in the past 14 days
At least one of:
- A successful authorization at an airline merchant (MCC 3000-3299, 4511) where the destination city matches the country of the current alerted transaction
- A hotel authorization (MCC 3501-3999, 7011) in the same country as the alerted transaction
- A rideshare transaction (MCC 4121) in the same country in the prior 72 hours

### 3. Device continuity
The device ID on the alerted transaction matches a device that has been used on the account for at least 30 days.

### 4. No proxy / VPN indicator
The IP address on the alerted transaction does not match any of: known TOR exit nodes, datacenter IP ranges, commercial VPN providers.

## Decision
- All four criteria satisfied → **SUPPRESS** the alert and approve the transaction
- Three of four criteria satisfied → reduce risk score by 30 points and route to standard review
- Two or fewer satisfied → no suppression; treat as Pattern P-002

## Reference cases
- Suppression analysis monthly report — see Cortex Search index `FRAUD_OPS.DOCS.FRAUD_PATTERN_INDEX` for the rolling FP rate
- Audit sample of 500 alerts, March 2026: applying this rule reduced FP rate from 38% to 11% while missing zero true-positive cases

## Notes for the agent
When you encounter a geographic-anomaly signal, always check this suppression rule before escalating. The travel signal need not be on the same card; check any card belonging to the same customer.
 $$;