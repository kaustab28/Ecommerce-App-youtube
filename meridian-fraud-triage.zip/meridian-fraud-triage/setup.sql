/*****************************************************************************************
 Meridian Bank — Agentic Fraud Triage System
 setup.sql

 Purpose:
   Provision the Snowflake objects required for the fraud triage pipeline.

 Milestone 1 scope:
   - Create roles, warehouse, database, and schemas
   - Create raw/reference tables
   - Load CSV files
   - Build Dynamic Tables for enrichment and velocity features
   - Build TRIAGE_QUEUE_DT containing the 11 pending review transactions

 Notes:
   - Runtime agent role must not be ACCOUNTADMIN.
   - ACCOUNTADMIN may be used only for initial provisioning.
   - The final agent will write actions to queue/outbox tables, not directly to issuer APIs.
******************************************************************************************/

-- ======================================================================================
-- 1. ADMIN SETUP
-- ======================================================================================
-- Run this section using ACCOUNTADMIN or another sufficiently privileged admin role.
-- The runtime role FRAUD_AGENT_RUNNER must be used later for agent/task execution.

USE ROLE ACCOUNTADMIN;

CREATE ROLE IF NOT EXISTS FRAUD_AGENT_RUNNER;

CREATE WAREHOUSE IF NOT EXISTS FRAUD_WH
  WAREHOUSE_SIZE = 'SMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE
  COMMENT = 'Warehouse for Meridian fraud triage project';

CREATE DATABASE IF NOT EXISTS MERIDIAN_FRAUD_DB
  COMMENT = 'End-to-end agentic fraud triage project database';

USE DATABASE MERIDIAN_FRAUD_DB;

CREATE SCHEMA IF NOT EXISTS RAW
  COMMENT = 'Raw landing schema for transaction events';

CREATE SCHEMA IF NOT EXISTS REF
  COMMENT = 'Reference/master data schema';

CREATE SCHEMA IF NOT EXISTS FEATURES
  COMMENT = 'Feature engineering and triage queue schema';

CREATE SCHEMA IF NOT EXISTS APP
  COMMENT = 'Application tables, action queues, procedures, tasks, and audit logs';

CREATE SCHEMA IF NOT EXISTS KNOWLEDGE
  COMMENT = 'Fraud playbook documents and Cortex Search objects';

CREATE SCHEMA IF NOT EXISTS SEMANTIC
  COMMENT = 'Cortex Analyst semantic model artifacts';

GRANT USAGE ON WAREHOUSE FRAUD_WH TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON DATABASE MERIDIAN_FRAUD_DB TO ROLE FRAUD_AGENT_RUNNER;

GRANT USAGE ON SCHEMA RAW TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA REF TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA FEATURES TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA APP TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA KNOWLEDGE TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA SEMANTIC TO ROLE FRAUD_AGENT_RUNNER;


-- ======================================================================================
-- 2. FILE FORMAT AND INTERNAL STAGES
-- ======================================================================================

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;

CREATE OR REPLACE FILE FORMAT RAW.CSV_FF
  TYPE = CSV
  SKIP_HEADER = 1
  FIELD_OPTIONALLY_ENCLOSED_BY = '"'
  NULL_IF = ('NULL', 'null', '')
  EMPTY_FIELD_AS_NULL = TRUE
  TRIM_SPACE = TRUE;

CREATE STAGE IF NOT EXISTS RAW.DATA_STAGE
  FILE_FORMAT = RAW.CSV_FF
  COMMENT = 'Internal stage for CSV input files';

CREATE STAGE IF NOT EXISTS KNOWLEDGE.PATTERN_STAGE
  COMMENT = 'Internal stage for fraud pattern markdown documents';

-- ======================================================================================
-- 3. RAW AND REFERENCE TABLES
-- ======================================================================================

CREATE OR REPLACE TABLE REF.CUSTOMERS (
  customer_id              VARCHAR,
  full_name                VARCHAR,
  email                    VARCHAR,
  phone                    VARCHAR,
  date_of_birth            DATE,
  home_city                VARCHAR,
  home_country             VARCHAR,
  account_open_date        DATE,
  avg_monthly_spend_usd    NUMBER(14,2),
  customer_tier            VARCHAR,
  kyc_status               VARCHAR,
  risk_tier                VARCHAR
);

CREATE OR REPLACE TABLE REF.MERCHANTS (
  merchant_id              VARCHAR,
  merchant_name            VARCHAR,
  merchant_category        VARCHAR,
  mcc_code                 VARCHAR,
  city                     VARCHAR,
  country                  VARCHAR,
  registered_date          DATE,
  chargeback_rate_pct      NUMBER(8,2),
  merchant_risk_rating     VARCHAR,
  is_high_risk_category    BOOLEAN
);

CREATE OR REPLACE TABLE REF.HISTORICAL_FRAUD_CASES (
  case_id                  VARCHAR,
  customer_id              VARCHAR,
  fraud_type               VARCHAR,
  first_fraud_txn_ts       TIMESTAMP_NTZ,
  detected_at_ts           TIMESTAMP_NTZ,
  total_loss_usd           NUMBER(14,2),
  num_fraudulent_txns      NUMBER,
  resolution               VARCHAR,
  root_cause_summary       STRING
);

CREATE OR REPLACE TABLE RAW.RAW_TRANSACTIONS (
  transaction_id           VARCHAR,
  customer_id              VARCHAR,
  merchant_id              VARCHAR,
  amount_usd               NUMBER(14,2),
  currency                 VARCHAR,
  transaction_ts           TIMESTAMP_NTZ,
  channel                  VARCHAR,
  card_present             BOOLEAN,
  device_id                VARCHAR,
  ip_address               VARCHAR,
  ip_country               VARCHAR,
  mcc_code                 VARCHAR,
  authorization_status     VARCHAR,
  risk_score               NUMBER(5,0),
  initial_decision         VARCHAR,
  loaded_at                TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- ======================================================================================
-- 4. LOAD CSV DATA
-- ======================================================================================
-- Make sure the CSV files are uploaded to @RAW.DATA_STAGE before running this section.

COPY INTO REF.CUSTOMERS
FROM @RAW.DATA_STAGE/customers.csv
FILE_FORMAT = RAW.CSV_FF
ON_ERROR = 'ABORT_STATEMENT';

COPY INTO REF.MERCHANTS
FROM @RAW.DATA_STAGE/merchants.csv
FILE_FORMAT = RAW.CSV_FF
ON_ERROR = 'ABORT_STATEMENT';

COPY INTO REF.HISTORICAL_FRAUD_CASES
FROM @RAW.DATA_STAGE/historical_fraud_cases.csv
FILE_FORMAT = RAW.CSV_FF
ON_ERROR = 'ABORT_STATEMENT';

COPY INTO RAW.RAW_TRANSACTIONS (
  transaction_id,
  customer_id,
  merchant_id,
  amount_usd,
  currency,
  transaction_ts,
  channel,
  card_present,
  device_id,
  ip_address,
  ip_country,
  mcc_code,
  authorization_status,
  risk_score,
  initial_decision
)
FROM @RAW.DATA_STAGE/transactions.csv
FILE_FORMAT = RAW.CSV_FF
ON_ERROR = 'ABORT_STATEMENT';


-- ======================================================================================
-- 5. LOAD VALIDATION
-- ======================================================================================

SELECT 'CUSTOMERS' AS table_name, COUNT(*) AS row_count FROM REF.CUSTOMERS
UNION ALL
SELECT 'MERCHANTS', COUNT(*) FROM REF.MERCHANTS
UNION ALL
SELECT 'HISTORICAL_FRAUD_CASES', COUNT(*) FROM REF.HISTORICAL_FRAUD_CASES
UNION ALL
SELECT 'RAW_TRANSACTIONS', COUNT(*) FROM RAW.RAW_TRANSACTIONS;

-- ======================================================================================
-- 6. BASE ENRICHED TRANSACTIONS DYNAMIC TABLE
-- ======================================================================================

CREATE OR REPLACE DYNAMIC TABLE FEATURES.ENRICHED_TRANSACTIONS_DT
  TARGET_LAG = '1 minute'
  WAREHOUSE = FRAUD_WH
AS
SELECT
  t.transaction_id,
  t.customer_id,
  t.merchant_id,
  t.amount_usd,
  t.currency,
  t.transaction_ts,
  t.channel,
  t.card_present,
  t.device_id,
  t.ip_address,
  t.ip_country,
  t.mcc_code AS transaction_mcc_code,
  t.authorization_status,
  t.risk_score,
  t.initial_decision,

  c.full_name,
  c.email,
  c.phone,
  c.date_of_birth,
  c.home_city,
  c.home_country,
  c.account_open_date,
  c.avg_monthly_spend_usd,
  c.customer_tier,
  c.kyc_status,
  c.risk_tier,

  m.merchant_name,
  m.merchant_category,
  m.mcc_code AS merchant_mcc_code,
  m.city AS merchant_city,
  m.country AS merchant_country,
  m.registered_date AS merchant_registered_date,
  m.chargeback_rate_pct,
  m.merchant_risk_rating,
  m.is_high_risk_category,

  DATEDIFF('day', c.account_open_date, t.transaction_ts) AS customer_account_age_days,
  DATEDIFF('day', m.registered_date, t.transaction_ts) AS merchant_age_days,

  IFF(m.country <> c.home_country, TRUE, FALSE) AS merchant_country_mismatch,
  IFF(t.ip_country <> c.home_country, TRUE, FALSE) AS ip_country_mismatch,

  IFF(t.amount_usd > c.avg_monthly_spend_usd, TRUE, FALSE) AS amount_gt_monthly_avg,
  ROUND(t.amount_usd / NULLIF(c.avg_monthly_spend_usd, 0), 4) AS amount_to_monthly_spend_ratio,

  IFF(t.channel IN ('ONLINE', 'RECURRING'), TRUE, FALSE) AS is_card_not_present,
  IFF(HOUR(t.transaction_ts) BETWEEN 2 AND 4, TRUE, FALSE) AS is_off_hours,

  IFF(m.registered_date >= DATEADD('month', -12, t.transaction_ts), TRUE, FALSE) AS merchant_registered_lt_12mo,

  IFF(m.mcc_code IN ('6051', '4829'), TRUE, FALSE) AS is_crypto_or_money_transfer,
  IFF(MOD(t.amount_usd, 100) = 0, TRUE, FALSE) AS is_round_100_amount

FROM RAW.RAW_TRANSACTIONS t
LEFT JOIN REF.CUSTOMERS c
  ON t.customer_id = c.customer_id
LEFT JOIN REF.MERCHANTS m
  ON t.merchant_id = m.merchant_id;

-- ======================================================================================
-- 7. CUSTOMER VELOCITY FEATURES DYNAMIC TABLE
-- ======================================================================================
-- This table computes customer-level rolling features before each transaction.
-- These features are essential for detecting bursts such as card testing.

CREATE OR REPLACE DYNAMIC TABLE FEATURES.CUSTOMER_VELOCITY_DT
  TARGET_LAG = '1 minute'
  WAREHOUSE = FRAUD_WH
AS
SELECT
  cur.transaction_id,

  COUNT(prev_15.transaction_id) AS txn_count_15m,
  COALESCE(SUM(prev_15.amount_usd), 0) AS txn_sum_15m,
  COUNT_IF(prev_15.amount_usd < 10) AS small_txn_count_15m,
  AVG(IFF(prev_15.amount_usd < 10, prev_15.amount_usd, NULL)) AS avg_small_txn_amount_15m,

  COUNT(prev_1h.transaction_id) AS txn_count_1h,
  COALESCE(SUM(prev_1h.amount_usd), 0) AS txn_sum_1h,

  COUNT(prev_24h.transaction_id) AS txn_count_24h,
  COALESCE(SUM(prev_24h.amount_usd), 0) AS txn_sum_24h,

  COUNT(DISTINCT prev_30d.device_id) AS distinct_devices_30d,
  COUNT(DISTINCT prev_30d.ip_country) AS distinct_ip_countries_30d,
  COUNT(DISTINCT prev_30d.merchant_id) AS distinct_merchants_30d,

  COUNT_IF(prev_30d.device_id = cur.device_id) AS same_device_prior_count_30d,
  IFF(COUNT_IF(prev_30d.device_id = cur.device_id) > 0, FALSE, TRUE) AS is_new_device_for_customer,

  COUNT_IF(prev_30d.merchant_id = cur.merchant_id) AS same_merchant_prior_count_30d,
  IFF(COUNT_IF(prev_30d.merchant_id = cur.merchant_id) > 0, FALSE, TRUE) AS is_new_merchant_for_customer,

  COUNT_IF(prev_30d.mcc_code = cur.mcc_code) AS same_mcc_prior_count_30d,

  COUNT_IF(prev_30d.mcc_code IN ('3000', '3001', '3002', '4511', '7011', '4121')) AS travel_signal_count_30d,

  COUNT_IF(prev_14d.mcc_code = '4511') AS airline_signal_count_14d,
  COUNT_IF(prev_14d.mcc_code = '7011') AS hotel_signal_count_14d,
  COUNT_IF(prev_72h.mcc_code = '4121') AS rideshare_signal_count_72h,

  COUNT_IF(prev_30d.mcc_code = '6051') AS prior_crypto_txn_count_30d,
  COUNT_IF(prev_30d.mcc_code = '4829') AS prior_money_transfer_txn_count_30d

FROM RAW.RAW_TRANSACTIONS cur

LEFT JOIN RAW.RAW_TRANSACTIONS prev_15
  ON cur.customer_id = prev_15.customer_id
 AND prev_15.transaction_ts < cur.transaction_ts
 AND prev_15.transaction_ts >= DATEADD('minute', -15, cur.transaction_ts)

LEFT JOIN RAW.RAW_TRANSACTIONS prev_1h
  ON cur.customer_id = prev_1h.customer_id
 AND prev_1h.transaction_ts < cur.transaction_ts
 AND prev_1h.transaction_ts >= DATEADD('hour', -1, cur.transaction_ts)

LEFT JOIN RAW.RAW_TRANSACTIONS prev_24h
  ON cur.customer_id = prev_24h.customer_id
 AND prev_24h.transaction_ts < cur.transaction_ts
 AND prev_24h.transaction_ts >= DATEADD('hour', -24, cur.transaction_ts)

LEFT JOIN RAW.RAW_TRANSACTIONS prev_30d
  ON cur.customer_id = prev_30d.customer_id
 AND prev_30d.transaction_ts < cur.transaction_ts
 AND prev_30d.transaction_ts >= DATEADD('day', -30, cur.transaction_ts)

LEFT JOIN RAW.RAW_TRANSACTIONS prev_14d
  ON cur.customer_id = prev_14d.customer_id
 AND prev_14d.transaction_ts < cur.transaction_ts
 AND prev_14d.transaction_ts >= DATEADD('day', -14, cur.transaction_ts)

LEFT JOIN RAW.RAW_TRANSACTIONS prev_72h
  ON cur.customer_id = prev_72h.customer_id
 AND prev_72h.transaction_ts < cur.transaction_ts
 AND prev_72h.transaction_ts >= DATEADD('hour', -72, cur.transaction_ts)

GROUP BY
  cur.transaction_id;


-- ======================================================================================
-- 8. TRIAGE QUEUE DYNAMIC TABLE
-- ======================================================================================
-- This table surfaces only transactions that require agent triage.

CREATE OR REPLACE DYNAMIC TABLE FEATURES.TRIAGE_QUEUE_DT
  TARGET_LAG = '1 minute'
  WAREHOUSE = FRAUD_WH
AS
SELECT
  e.*,

  v.txn_count_15m,
  v.txn_sum_15m,
  v.small_txn_count_15m,
  v.avg_small_txn_amount_15m,
  v.txn_count_1h,
  v.txn_sum_1h,
  v.txn_count_24h,
  v.txn_sum_24h,
  v.distinct_devices_30d,
  v.distinct_ip_countries_30d,
  v.distinct_merchants_30d,
  v.same_device_prior_count_30d,
  v.is_new_device_for_customer,
  v.same_merchant_prior_count_30d,
  v.is_new_merchant_for_customer,
  v.same_mcc_prior_count_30d,
  v.travel_signal_count_30d,
  v.airline_signal_count_14d,
  v.hotel_signal_count_14d,
  v.rideshare_signal_count_72h,
  v.prior_crypto_txn_count_30d,
  v.prior_money_transfer_txn_count_30d,

  CASE
    WHEN e.risk_score >= 70
     AND e.initial_decision = 'REVIEW'
     AND e.authorization_status = 'PENDING_REVIEW'
    THEN TRUE
    ELSE FALSE
  END AS should_triage

FROM FEATURES.ENRICHED_TRANSACTIONS_DT e
LEFT JOIN FEATURES.CUSTOMER_VELOCITY_DT v
  ON e.transaction_id = v.transaction_id
WHERE e.risk_score >= 70
  AND e.initial_decision = 'REVIEW'
  AND e.authorization_status = 'PENDING_REVIEW';


-- ======================================================================================
-- 9. MILESTONE 1 VALIDATION QUERIES
-- ======================================================================================

-- Expected: 11
SELECT COUNT(*) AS triage_count
FROM FEATURES.TRIAGE_QUEUE_DT;

-- Expected: the 11 required transaction IDs
SELECT
  transaction_id,
  customer_id,
  merchant_id,
  merchant_name,
  amount_usd,
  transaction_ts,
  channel,
  card_present,
  device_id,
  ip_country,
  merchant_country,
  risk_score,
  txn_count_15m,
  small_txn_count_15m,
  is_new_device_for_customer,
  is_new_merchant_for_customer,
  merchant_risk_rating,
  is_high_risk_category
FROM FEATURES.TRIAGE_QUEUE_DT
ORDER BY transaction_ts;

-- Useful check for the P-001 burst
SELECT
  transaction_id,
  customer_id,
  amount_usd,
  transaction_ts,
  merchant_name,
  txn_count_15m,
  small_txn_count_15m,
  avg_small_txn_amount_15m,
  is_new_device_for_customer,
  is_new_merchant_for_customer
FROM FEATURES.TRIAGE_QUEUE_DT
WHERE customer_id = 'CUST006'
ORDER BY transaction_ts;

-- Useful check for P-005 Tokyo suppression candidate
SELECT
  transaction_id,
  customer_id,
  amount_usd,
  transaction_ts,
  merchant_name,
  merchant_country,
  customer_tier,
  channel,
  card_present,
  device_id,
  ip_country,
  travel_signal_count_30d,
  airline_signal_count_14d,
  hotel_signal_count_14d,
  rideshare_signal_count_72h,
  is_new_device_for_customer
FROM FEATURES.TRIAGE_QUEUE_DT
WHERE customer_id = 'CUST007'
ORDER BY transaction_ts;

SELECT
  transaction_id,
  customer_id,
  merchant_id,
  merchant_name,
  amount_usd,
  transaction_ts,
  risk_score
FROM FEATURES.TRIAGE_QUEUE_DT
ORDER BY transaction_ts;

-- ======================================================================================
-- 10. KNOWLEDGE TABLE FOR FRAUD PATTERN PLAYBOOK DOCUMENTS
-- ======================================================================================
-- The markdown files are loaded into this table as text documents.
-- Cortex Search indexes the CONTENT column.

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA KNOWLEDGE;

CREATE OR REPLACE TABLE KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id      VARCHAR,
  file_name       VARCHAR,
  title           VARCHAR,
  category        VARCHAR,
  severity        VARCHAR,
  content         STRING,
  loaded_at       TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

--generated sql inserts from Markdown files
USE DATABASE MERIDIAN_FRAUD_DB;

USE SCHEMA KNOWLEDGE;

TRUNCATE TABLE KNOWLEDGE.FRAUD_PATTERN_DOCS;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-001',
  'P001_card_testing_bustout.md',
  'Card Testing Followed by Bust-Out',
  'Card-Not-Present Fraud',
  'HIGH',
  $$ # Fraud Pattern P-001: Card Testing Followed by Bust-Out

**Pattern ID:** P-001
**Category:** Card-Not-Present (CNP) Fraud
**Severity:** HIGH
**Last reviewed:** 2026-03-15

## Signature
Fraudsters who have purchased or stolen a batch of card numbers will first verify which cards are still active before attempting any large-value transaction. The verification phase is characterized by a sequence of micro-charges at low-friction merchants. Once a card responds with an authorization, the same card is hit with a large charge within minutes.

## Detection signals
- 3 or more transactions on the same PAN within a 15-minute window
- Individual amounts under USD 10, often ending in .99 or .49
- Merchants in **MCC 5815** (digital downloads), **MCC 5816** (game vouchers), or **MCC 5967** (direct marketing — outbound telemarketing)
- Merchant in a different country than the cardholder's billing country
- IP address from a hosting/VPN range or a country mismatched with the cardholder
- Device ID not previously seen on the account
- All transactions in card-not-present (CNP) channel
- A final transaction with amount > 50x the average of the testing burst

## Typical merchant clusters
- Cyprus, Malta, Isle of Man, and Gibraltar registered digital goods merchants
- Newly registered merchants (< 12 months) with elevated chargeback rates
- Gaming top-up resellers in Southeast Asia

## Recommended action when matched
1. Decline the largest pending authorization
2. Freeze the card and issue a replacement
3. Reverse-charge all successful test transactions
4. Notify the cardholder via the registered mobile number (not email — assume email is compromised)
5. Escalate to the fraud analyst queue with priority FRAUD-HIGH

## Reference cases
- FC2025-0411 — confirmed loss USD 3,450
- FC2026-0208 — confirmed loss USD 2,890

## False-positive considerations
A legitimate customer trialing a new subscription service may produce two or three small charges. The defining marker is the **bust-out transaction** within the same 30-minute window. Without the large follow-on, treat as low-priority review.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-002',
  'P002_geographic_anomaly.md',
  'Geographic Anomaly / Impossible Travel',
  'Counterfeit / Cloned Card Fraud',
  'HIGH',
  $$ # Fraud Pattern P-002: Geographic Anomaly / Impossible Travel

**Pattern ID:** P-002
**Category:** Counterfeit / Cloned Card Fraud
**Severity:** HIGH
**Last reviewed:** 2026-02-20

## Signature
A card is used in a location physically incompatible with the cardholder's verified position at the same time, or with their established travel pattern. This typically indicates the card has been cloned (magstripe skimmed or e-commerce credentials leaked) and is being used by a separate party while the customer still possesses the physical card.

## Detection signals
- Transaction country differs from cardholder's home country
- No travel signal in the prior 14 days (no airline, lodging, or rideshare bookings)
- Transaction occurs during cardholder's typical sleeping hours in their home time zone
- IP geolocation places the device in a third country (often Eastern Europe, Southeast Asia, or West Africa proxy locations)
- Single high-value transaction rather than a sequence
- Merchant categories favored: jewelry (MCC 5944), electronics (MCC 5732), forex (MCC 4829), gold dealers

## Heightening factors
- Card was recently used at a known compromised merchant
- A "card present" flag on a foreign POS while the cardholder's device is geolocated at home
- Customer has no prior history of international transactions

## Recommended action when matched
1. Hard decline if pending; chargeback recall if already settled
2. Block the card immediately
3. Verify cardholder location via app push, then SMS, then phone
4. If verified fraud: open a case, file SAFE (Suspicious Activity File Exchange) report, request merchant transaction record
5. Issue a replacement card

## Reference cases
- FC2025-0529 — Kuala Lumpur jewelry while cardholder was in Boston — USD 8,200
- FC2026-0303 — Bangkok jewelry while cardholder was in Chicago — USD 4,850

## False-positive considerations
Frequent international travelers (segment tier PLATINUM with > 4 foreign trips per year) often produce this signal legitimately. Look for corroborating travel evidence in the past 14 days. If the customer's prior month includes an airline transaction whose destination matches the current country, suppress alert unless other signals (new device, proxy IP, atypical merchant) are also present.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-003',
  'P003_account_takeover.md',
  'Account Takeover',
  'Credential / Session Compromise',
  'HIGH',
  $$ # Fraud Pattern P-003: Account Takeover (ATO)

**Pattern ID:** P-003
**Category:** Credential / Session Compromise
**Severity:** HIGH
**Last reviewed:** 2026-04-02

## Signature
An attacker gains control of the customer's online banking or wallet credentials (via phishing, credential stuffing, SIM swap, or malware) and uses the legitimate card credentials from a new device. Unlike cloning, the transaction routes through the customer's own account but originates from an attacker-controlled session.

## Detection signals
- Login from a device ID never seen on the account
- Login or transaction during cardholder's typical off-hours (especially 02:00 - 05:00 local time)
- Within 24 hours of any of: password reset, email change, phone number change, new device enrollment, SIM swap notice
- High-value purchase at a merchant the cardholder has never transacted with
- Merchant categories favored: luxury watches and jewelry (MCC 5944), electronics (MCC 5732), money transfer (MCC 4829)
- Shipping address differs from the billing address
- Multiple transactions clustered in a single session, often at distinct merchants

## Recommended action when matched
1. Decline the pending authorization
2. Block all sessions across the customer's accounts
3. Force re-authentication via out-of-band channel (registered phone callback, not SMS)
4. Notify the cardholder by voice call, not email or SMS, since both may be compromised
5. Open ATO investigation case in the fraud-ops queue

## Reference cases
- FC2025-0712 — overnight jewelry purchases from new Windows device — USD 5,670
- FC2026-0421 — luxury watch after ignored SIM swap notice — USD 3,200

## False-positive considerations
A customer who legitimately replaces their phone or laptop will produce a new-device login. The defining marker is the **combination** of new device + off-hours + high-value at unfamiliar merchant. Any one of these alone is not sufficient. The customer-initiated device enrollment (which produces a confirmation event in our auth logs) should suppress the device-novelty signal for 7 days.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-004',
  'P004_crypto_scam.md',
  'Authorized Push Payment to Crypto',
  'Authorized Push Payment Fraud',
  'MEDIUM-HIGH',
  $$ # Fraud Pattern P-004: Authorized Push Payment to Crypto (Scam Victim)

**Pattern ID:** P-004
**Category:** Authorized Push Payment Fraud (Scam Victim)
**Severity:** MEDIUM-HIGH
**Last reviewed:** 2026-04-25

## Signature
The cardholder themselves initiates a transaction to a cryptocurrency exchange or money-transfer merchant, but is doing so under the influence of a third-party scam (investment scam, romance scam, impersonation scam, employment scam). The transaction is **authenticated by the genuine customer** which makes it technically authorized, but the customer is a victim of social engineering.

## Detection signals
- First-ever transaction to a cryptocurrency merchant (MCC 6051) or money transfer service (MCC 4829)
- Transaction amount is a round number (e.g. USD 2,000 / 5,000 / 10,000)
- Customer demographic profile not typically associated with crypto investing (e.g. retiree, very young new-account holder)
- Funds transferred to the customer's account from a savings or external source in the 48 hours prior
- Multiple smaller transactions over days rather than a single large one
- Customer attempted the same transaction earlier and it was declined for limit reasons

## Recommended action when matched
1. **Do not auto-decline** — the customer authorized the transaction
2. Insert a friction step in the payment flow: a scam-awareness interstitial in the mobile app
3. Outbound call from the fraud team within 1 hour of the transaction
4. Provide the customer with reporting resources (FTC / Action Fraud / local equivalent)
5. Log a scam-victim flag on the account; subsequent crypto transactions should re-trigger the interstitial for 90 days

## Reference cases
- FC2026-0505 — USD 6,500 to crypto exchange after a romance scam

## False-positive considerations
Legitimate crypto investing is increasingly common, especially among customers aged 25-45. The defining marker is the **combination** of: first-ever crypto, atypical demographic, recent inbound funding to the source account, and round-number amount. Two or fewer signals = legitimate trader. Three or more = probable scam victim. Treat with empathy regardless of outcome — these customers are victims, not perpetrators.
 $$;

INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  'P-005',
  'P005_frequent_traveler_suppression.md',
  'Frequent Traveler False Positive Suppression',
  'False-Positive Suppression Rule',
  'N/A',
  $$ # Fraud Pattern P-005: Frequent Traveler — False Positive Suppression

**Pattern ID:** P-005
**Category:** False-Positive Suppression Rule
**Severity:** N/A (suppression rule)
**Last reviewed:** 2026-01-30

## Purpose
This document describes the corroborating evidence required to suppress geographic-anomaly alerts (Pattern P-002) when the cardholder is on legitimate international travel. Approximately 38% of geographic-anomaly alerts in our portfolio are false positives driven by frequent travelers, so accurate suppression is essential to reduce review queue load.

## Suppression criteria — all of the following must hold

### 1. Established travel pattern
The customer's tier is GOLD or PLATINUM **and** has at least 3 prior cross-border transactions in the past 12 months.

### 2. Corroborating travel signal in the past 14 days
At least one of:
- A successful authorization at an airline merchant (MCC 3000-3299, 4511) where the destination city matches the country of the current alerted transaction
- A hotel authorization (MCC 3501-3999, 7011) in the same country as the alerted transaction
- A rideshare transaction (MCC 4121) in the same country in the prior 72 hours

### 3. Device continuity
The device ID on the alerted transaction matches a device that has been used on the account for at least 30 days.

### 4. No proxy / VPN indicator
The IP address on the alerted transaction does not match any of: known TOR exit nodes, datacenter IP ranges, commercial VPN providers.

## Decision
- All four criteria satisfied → **SUPPRESS** the alert and approve the transaction
- Three of four criteria satisfied → reduce risk score by 30 points and route to standard review
- Two or fewer satisfied → no suppression; treat as Pattern P-002

## Reference cases
- Suppression analysis monthly report — see Cortex Search index `FRAUD_OPS.DOCS.FRAUD_PATTERN_INDEX` for the rolling FP rate
- Audit sample of 500 alerts, March 2026: applying this rule reduced FP rate from 38% to 11% while missing zero true-positive cases

## Notes for the agent
When you encounter a geographic-anomaly signal, always check this suppression rule before escalating. The travel signal need not be on the same card; check any card belonging to the same customer.
 $$;

--validating the playbook table 
SELECT
  pattern_id,
  file_name,
  title,
  category,
  severity,
  LENGTH(content) AS content_chars
FROM KNOWLEDGE.FRAUD_PATTERN_DOCS
ORDER BY pattern_id;

SELECT COUNT(*) AS pattern_doc_count
FROM KNOWLEDGE.FRAUD_PATTERN_DOCS;

--create cortex search service

CREATE OR REPLACE CORTEX SEARCH SERVICE FRAUD_PATTERN_SEARCH_SERVICE
  ON content
  PRIMARY KEY (pattern_id)
  ATTRIBUTES pattern_id, file_name, title, category, severity
  WAREHOUSE = FRAUD_WH
  TARGET_LAG = '1 minute'
AS
SELECT
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
FROM MERIDIAN_FRAUD_DB.KNOWLEDGE.FRAUD_PATTERN_DOCS;

SHOW CORTEX SEARCH SERVICES IN SCHEMA MERIDIAN_FRAUD_DB.KNOWLEDGE;

--TESTING CORTEX SEARCH 
--Test 1 — P-001 card testing
SELECT PARSE_JSON(
  SNOWFLAKE.CORTEX.SEARCH_PREVIEW(
    'MERIDIAN_FRAUD_DB.KNOWLEDGE.FRAUD_PATTERN_SEARCH_SERVICE',
    '{
      "query": "multiple small online charges followed by a large bust-out transaction",
      "columns": ["pattern_id", "title", "category", "severity", "content"],
      "limit": 3
    }'
  )
) AS search_results;


-- Test 2: Geographic anomaly with possible frequent-traveler suppression
-- Expected useful matches: P-005 and P-002

SELECT
  PARSE_JSON(
    SNOWFLAKE.CORTEX.SEARCH_PREVIEW(
      'MERIDIAN_FRAUD_DB.KNOWLEDGE.FRAUD_PATTERN_SEARCH_SERVICE',
      $$
      {
        "query": "foreign transaction geographic anomaly customer traveling hotel airline rideshare suppression rule frequent traveler",
        "columns": [
          "pattern_id",
          "title",
          "category",
          "severity",
          "content"
        ],
        "limit": 3
      }
      $$
    )
  ) AS search_results;

-- Test 3: Authorized push payment / crypto scam
-- Expected useful match: P-004

SELECT
  PARSE_JSON(
    SNOWFLAKE.CORTEX.SEARCH_PREVIEW(
      'MERIDIAN_FRAUD_DB.KNOWLEDGE.FRAUD_PATTERN_SEARCH_SERVICE',
      $$
      {
        "query": "cryptocurrency exchange money transfer round number first crypto transaction scam victim do not auto decline",
        "columns": [
          "pattern_id",
          "title",
          "category",
          "severity",
          "content"
        ],
        "limit": 3
      }
      $$
    )
  ) AS search_results;

  -- ======================================================================================
-- 12. CORTEX ANALYST SEMANTIC MODEL STAGE
-- ======================================================================================
-- The semantic_model.yaml file will be uploaded to this stage.
-- Cortex Analyst can use a semantic model YAML file stored in a Snowflake stage.

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;

CREATE STAGE IF NOT EXISTS SEMANTIC.MODEL_STAGE
  DIRECTORY = (ENABLE = TRUE)
  COMMENT = 'Stage for Cortex Analyst semantic model YAML files';

-- Grant Cortex usage.
-- Required for roles that call Cortex services.
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE FRAUD_AGENT_RUNNER;

-- Stage read access for the runner role.
GRANT READ ON STAGE SEMANTIC.MODEL_STAGE TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA SEMANTIC TO ROLE FRAUD_AGENT_RUNNER;

-- Table access needed by the semantic model.
GRANT SELECT ON DYNAMIC TABLE FEATURES.TRIAGE_QUEUE_DT TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT ON DYNAMIC TABLE FEATURES.ENRICHED_TRANSACTIONS_DT TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT ON TABLE REF.HISTORICAL_FRAUD_CASES TO ROLE FRAUD_AGENT_RUNNER;

-- Also grant schema/database usage explicitly.
GRANT USAGE ON DATABASE MERIDIAN_FRAUD_DB TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA FEATURES TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA REF TO ROLE FRAUD_AGENT_RUNNER;

LIST @MERIDIAN_FRAUD_DB.SEMANTIC.MODEL_STAGE;

--Testing basic table access

SELECT CURRENT_USER();
USE ROLE ACCOUNTADMIN;
GRANT ROLE FRAUD_AGENT_RUNNER TO USER KAUSTABCHAKRABORTY;
USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;

SELECT COUNT(*) AS triage_count
FROM FEATURES.TRIAGE_QUEUE_DT;

SELECT COUNT(*) AS enriched_transaction_count
FROM FEATURES.ENRICHED_TRANSACTIONS_DT;

SELECT COUNT(*) AS historical_case_count
FROM REF.HISTORICAL_FRAUD_CASES;


LIST @SEMANTIC.MODEL_STAGE;


-- ======================================================================================-- ================================================================================= RUNTIME TABLES
-- ======================================================================================
-- These tables support agent decisions, action queues, Slack escalation outbox,
-- and error logging.

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

-- --------------------------------------------------------------------------------------
-- 13.1 Card action queue
-- --------------------------------------------------------------------------------------
-- AUTO_BLOCK decisions do not call an issuer API directly.
-- They write an action request here for downstream fulfillment.

CREATE OR REPLACE TABLE APP.CARD_ACTION_QUEUE (
  action_id              STRING DEFAULT UUID_STRING(),
  transaction_id         STRING NOT NULL,
  customer_id            STRING NOT NULL,
  action_type            STRING NOT NULL, -- BLOCK_CARD, FREEZE_CARD, REISSUE_CARD, etc.
  action_reason          STRING,
  priority               STRING DEFAULT 'HIGH',
  requested_by           STRING DEFAULT CURRENT_USER(),
  requested_at           TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
  status                 STRING DEFAULT 'PENDING',
  decision_confidence    NUMBER(5,0),
  pattern_matched        STRING,
  raw_decision           VARIANT
);

-- --------------------------------------------------------------------------------------
-- 13.2 Slack outbox
-- --------------------------------------------------------------------------------------
-- ESCALATE decisions write a Slack-compatible payload here.
-- In production, this can be drained by an external function, Snowpark service,
-- or stored procedure using External Access Integration.

CREATE OR REPLACE TABLE APP.SLACK_OUTBOX (
  message_id             STRING DEFAULT UUID_STRING(),
  transaction_id         STRING NOT NULL,
  customer_id            STRING,
  channel_name           STRING DEFAULT '#fraud-triage',
  message_payload        VARIANT,
  message_text           STRING,
  created_at             TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
  sent_at                TIMESTAMP_NTZ,
  status                 STRING DEFAULT 'PENDING'
);

-- --------------------------------------------------------------------------------------
-- 13.3 Agent decisions audit table
-- --------------------------------------------------------------------------------------
-- Every valid agent decision is persisted here.
-- The full input, decision JSON, and tool trace are stored as VARIANT.

CREATE OR REPLACE TABLE APP.AGENT_DECISIONS (
  decision_id            STRING DEFAULT UUID_STRING(),
  transaction_id         STRING NOT NULL,
  customer_id            STRING,
  merchant_id            STRING,
  run_started_at         TIMESTAMP_NTZ,
  run_completed_at       TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
  latency_ms             NUMBER,
  decision               STRING,
  confidence             NUMBER(5,0),
  pattern_matched        STRING,
  justification          STRING,
  tools_used             ARRAY,
  agent_input            VARIANT,
  agent_output           VARIANT,
  tool_trace             VARIANT,
  model_name             STRING,
  created_by             STRING DEFAULT CURRENT_USER()
);

-- --------------------------------------------------------------------------------------
-- 13.4 Agent errors table
-- --------------------------------------------------------------------------------------
-- Parsing failures, invalid JSON, invalid decision values, and runtime errors go here.

CREATE OR REPLACE TABLE APP.AGENT_ERRORS (
  error_id               STRING DEFAULT UUID_STRING(),
  transaction_id         STRING,
  customer_id            STRING,
  error_stage            STRING,
  error_message          STRING,
  raw_agent_output       STRING,
  raw_payload            VARIANT,
  created_at             TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);


--Add Action Stored Procedures

-- ======================================================================================
-- 14. ACTION STORED PROCEDURES
-- ======================================================================================

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

-- --------------------------------------------------------------------------------------
-- 14.1 BLOCK_CARD
-- --------------------------------------------------------------------------------------
-- This procedure queues a card-block action.
-- It does not call an external issuer API directly.

CREATE OR REPLACE PROCEDURE APP.BLOCK_CARD(
    TRANSACTION_ID STRING,
    CUSTOMER_ID STRING,
    ACTION_REASON STRING,
    DECISION_CONFIDENCE NUMBER,
    PATTERN_MATCHED STRING,
    RAW_DECISION VARIANT
)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
  ACTION_ID STRING;
BEGIN
  ACTION_ID := UUID_STRING();

  INSERT INTO APP.CARD_ACTION_QUEUE (
    action_id,
    transaction_id,
    customer_id,
    action_type,
    action_reason,
    priority,
    decision_confidence,
    pattern_matched,
    raw_decision
  )
  SELECT
    :ACTION_ID,
    :TRANSACTION_ID,
    :CUSTOMER_ID,
    'BLOCK_CARD',
    :ACTION_REASON,
    'FRAUD-HIGH',
    :DECISION_CONFIDENCE,
    :PATTERN_MATCHED,
    :RAW_DECISION;

  RETURN OBJECT_CONSTRUCT(
    'status', 'QUEUED',
    'action_id', :ACTION_ID,
    'transaction_id', :TRANSACTION_ID,
    'action_type', 'BLOCK_CARD'
  );
END;
$$;

-- -------------------------------------------------------------------------------------- can be extended to call it
-- using External Access Integration.

--2.2 ESCALATE_TO_SLACK procedure

CREATE OR REPLACE PROCEDURE APP.ESCALATE_TO_SLACK(
    TRANSACTION_ID STRING,
    CUSTOMER_ID STRING,
    DECISION_CONFIDENCE NUMBER,
    PATTERN_MATCHED STRING,
    JUSTIFICATION STRING,
    RAW_DECISION VARIANT
)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
  MESSAGE_ID STRING;
  MESSAGE_TEXT STRING;
  PAYLOAD VARIANT;
BEGIN
  MESSAGE_ID := UUID_STRING();

  MESSAGE_TEXT :=
      'Fraud triage escalation for transaction '
      || :TRANSACTION_ID
      || '. Customer: '
      || :CUSTOMER_ID
      || '. Pattern: '
      || :PATTERN_MATCHED
      || '. Confidence: '
      || :DECISION_CONFIDENCE
      || '. Reason: '
      || :JUSTIFICATION;

  PAYLOAD := OBJECT_CONSTRUCT(
    'channel', '#fraud-triage',
    'text', :MESSAGE_TEXT,
    'transaction_id', :TRANSACTION_ID,
    'customer_id', :CUSTOMER_ID,
    'confidence', :DECISION_CONFIDENCE,
    'pattern_matched', :PATTERN_MATCHED,
    'raw_decision', :RAW_DECISION
  );

  INSERT INTO APP.SLACK_OUTBOX (
    message_id,
    transaction_id,
    customer_id,
    channel_name,
    message_payload,
    message_text,
    status
  )
  SELECT
    :MESSAGE_ID,
    :TRANSACTION_ID,
    :CUSTOMER_ID,
    '#fraud-triage',
    :PAYLOAD,
    :MESSAGE_TEXT,
    'PENDING';

  RETURN OBJECT_CONSTRUCT(
    'status', 'QUEUED',
    'message_id', :MESSAGE_ID,
    'transaction_id', :TRANSACTION_ID
  );
END;
$$;
-- 14.2 ESCALATE_TO_SLACK
-- --------------------------------------------------------------------------------------
-- This procedure writes a Slack-compatible message to SLACK_OUTBOX.


-- ======================================================================================
-- 15. PERSIST_AGENT_DECISION PROCEDURE
-- ======================================================================================
-- This procedure validates and persists the agent's final JSON decision.
-- If the agent returns invalid JSON or violates safety rules, the error is logged.

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

CREATE OR REPLACE PROCEDURE APP.PERSIST_AGENT_DECISION(
    TRANSACTION_ID STRING,
    AGENT_INPUT VARIANT,
    AGENT_OUTPUT_TEXT STRING,
    TOOL_TRACE VARIANT,
    MODEL_NAME STRING,
    RUN_STARTED_AT TIMESTAMP_NTZ
)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
  STEP_VALUE STRING DEFAULT 'START';

  CLEAN_OUTPUT_TEXT STRING;
  DECISION_JSON VARIANT;

  DECISION_VALUE STRING;
  CONFIDENCE_VALUE NUMBER;
  PATTERN_VALUE STRING;
  JUSTIFICATION_VALUE STRING;
  TOOLS_USED_VALUE ARRAY;

  CUSTOMER_ID_VALUE STRING;
  MERCHANT_ID_VALUE STRING;
  LATENCY_MS_VALUE NUMBER;

  ACTION_ID_VALUE STRING;
  MESSAGE_ID_VALUE STRING;
  MESSAGE_TEXT_VALUE STRING;
  MESSAGE_PAYLOAD_VALUE VARIANT;
  ACTION_RESULT VARIANT;

  ERROR_MESSAGE_VALUE STRING;
  ERROR_CODE_VALUE NUMBER;
  ERROR_STATE_VALUE STRING;
BEGIN

  STEP_VALUE := 'LOOKUP_TRANSACTION_METADATA';

  SELECT
    customer_id,
    merchant_id
  INTO
    :CUSTOMER_ID_VALUE,
    :MERCHANT_ID_VALUE
  FROM FEATURES.TRIAGE_QUEUE_DT
  WHERE transaction_id = :TRANSACTION_ID;

  STEP_VALUE := 'CLEAN_AGENT_OUTPUT';

  CLEAN_OUTPUT_TEXT := TRIM(AGENT_OUTPUT_TEXT);
  CLEAN_OUTPUT_TEXT := REGEXP_REPLACE(CLEAN_OUTPUT_TEXT, '^```json[[:space:]]*', '');
  CLEAN_OUTPUT_TEXT := REGEXP_REPLACE(CLEAN_OUTPUT_TEXT, '^```[[:space:]]*', '');
  CLEAN_OUTPUT_TEXT := REGEXP_REPLACE(CLEAN_OUTPUT_TEXT, '[[:space:]]*```$', '');
  CLEAN_OUTPUT_TEXT := TRIM(CLEAN_OUTPUT_TEXT);

  STEP_VALUE := 'PARSE_JSON';

  DECISION_JSON := TRY_PARSE_JSON(CLEAN_OUTPUT_TEXT);

  IF (DECISION_JSON IS NULL) THEN

    INSERT INTO APP.AGENT_ERRORS (
      transaction_id,
      customer_id,
      error_stage,
      error_message,
      raw_agent_output,
      raw_payload
    )
    SELECT
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      'JSON_PARSE',
      'Agent output was not valid JSON after cleanup.',
      :AGENT_OUTPUT_TEXT,
      OBJECT_CONSTRUCT(
        'agent_input', :AGENT_INPUT,
        'clean_output_text', :CLEAN_OUTPUT_TEXT
      )
    FROM TABLE(GENERATOR(ROWCOUNT => 1));

    RETURN OBJECT_CONSTRUCT(
      'status', 'ERROR',
      'error_stage', 'JSON_PARSE',
      'transaction_id', TRANSACTION_ID
    );

  END IF;

  STEP_VALUE := 'EXTRACT_JSON_FIELDS';

  DECISION_VALUE := DECISION_JSON:decision::STRING;
  CONFIDENCE_VALUE := DECISION_JSON:confidence::NUMBER;
  PATTERN_VALUE := DECISION_JSON:pattern_matched::STRING;
  JUSTIFICATION_VALUE := DECISION_JSON:justification::STRING;
  TOOLS_USED_VALUE := DECISION_JSON:tools_used::ARRAY;

  STEP_VALUE := 'VALIDATE_DECISION';

  IF (DECISION_VALUE IS NULL OR DECISION_VALUE NOT IN ('AUTO_BLOCK', 'ESCALATE', 'DISMISS')) THEN

    INSERT INTO APP.AGENT_ERRORS (
      transaction_id,
      customer_id,
      error_stage,
      error_message,
      raw_agent_output,
      raw_payload
    )
    SELECT
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      'VALIDATION',
      'Invalid decision. Expected AUTO_BLOCK, ESCALATE, or DISMISS.',
      :AGENT_OUTPUT_TEXT,
      :DECISION_JSON;

    RETURN OBJECT_CONSTRUCT(
      'status', 'ERROR',
      'error_stage', 'VALIDATION',
      'message', 'Invalid decision',
      'transaction_id', TRANSACTION_ID
    );

  END IF;

  STEP_VALUE := 'VALIDATE_CONFIDENCE';

  IF (CONFIDENCE_VALUE IS NULL OR CONFIDENCE_VALUE < 0 OR CONFIDENCE_VALUE > 100) THEN

    INSERT INTO APP.AGENT_ERRORS (
      transaction_id,
      customer_id,
      error_stage,
      error_message,
      raw_agent_output,
      raw_payload
    )
    SELECT
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      'VALIDATION',
      'Invalid confidence. Expected integer 0-100.',
      :AGENT_OUTPUT_TEXT,
      :DECISION_JSON;

    RETURN OBJECT_CONSTRUCT(
      'status', 'ERROR',
      'error_stage', 'VALIDATION',
      'message', 'Invalid confidence',
      'transaction_id', TRANSACTION_ID
    );

  END IF;

  STEP_VALUE := 'VALIDATE_PATTERN';

  IF (PATTERN_VALUE IS NULL OR PATTERN_VALUE NOT IN ('P-001', 'P-002', 'P-003', 'P-004', 'P-005', 'NONE')) THEN

    INSERT INTO APP.AGENT_ERRORS (
      transaction_id,
      customer_id,
      error_stage,
      error_message,
      raw_agent_output,
      raw_payload
    )
    SELECT
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      'VALIDATION',
      'Invalid pattern_matched value.',
      :AGENT_OUTPUT_TEXT,
      :DECISION_JSON;

    RETURN OBJECT_CONSTRUCT(
      'status', 'ERROR',
      'error_stage', 'VALIDATION',
      'message', 'Invalid pattern_matched',
      'transaction_id', TRANSACTION_ID
    );

  END IF;

  STEP_VALUE := 'VALIDATE_JUSTIFICATION';

  IF (JUSTIFICATION_VALUE IS NULL OR LENGTH(JUSTIFICATION_VALUE) = 0) THEN

    INSERT INTO APP.AGENT_ERRORS (
      transaction_id,
      customer_id,
      error_stage,
      error_message,
      raw_agent_output,
      raw_payload
    )
    SELECT
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      'VALIDATION',
      'Missing justification.',
      :AGENT_OUTPUT_TEXT,
      :DECISION_JSON;

    RETURN OBJECT_CONSTRUCT(
      'status', 'ERROR',
      'error_stage', 'VALIDATION',
      'message', 'Missing justification',
      'transaction_id', TRANSACTION_ID
    );

  END IF;

  STEP_VALUE := 'TRUNCATE_JUSTIFICATION';

  IF (LENGTH(JUSTIFICATION_VALUE) > 1500) THEN
    JUSTIFICATION_VALUE := LEFT(JUSTIFICATION_VALUE, 1500);
  END IF;

  STEP_VALUE := 'APPLY_SAFETY_GATE';

  IF (DECISION_VALUE = 'AUTO_BLOCK' AND CONFIDENCE_VALUE < 90) THEN

    DECISION_VALUE := 'ESCALATE';

    JUSTIFICATION_VALUE :=
      LEFT(
        'Safety override: agent proposed AUTO_BLOCK below 90 confidence. Original justification: '
        || COALESCE(JUSTIFICATION_VALUE, ''),
        1500
      );

  END IF;

  STEP_VALUE := 'CALCULATE_LATENCY';

  LATENCY_MS_VALUE := DATEDIFF('millisecond', RUN_STARTED_AT, CURRENT_TIMESTAMP());

  STEP_VALUE := 'INSERT_AGENT_DECISIONS';

  INSERT INTO APP.AGENT_DECISIONS (
    transaction_id,
    customer_id,
    merchant_id,
    run_started_at,
    run_completed_at,
    latency_ms,
    decision,
    confidence,
    pattern_matched,
    justification,
    tools_used,
    agent_input,
    agent_output,
    tool_trace,
    model_name
  )
  SELECT
    :TRANSACTION_ID,
    :CUSTOMER_ID_VALUE,
    :MERCHANT_ID_VALUE,
    :RUN_STARTED_AT,
    CURRENT_TIMESTAMP(),
    :LATENCY_MS_VALUE,
    :DECISION_VALUE,
    :CONFIDENCE_VALUE,
    :PATTERN_VALUE,
    :JUSTIFICATION_VALUE,
    :TOOLS_USED_VALUE,
    :AGENT_INPUT,
    :DECISION_JSON,
    :TOOL_TRACE,
    :MODEL_NAME;

  STEP_VALUE := 'SIDE_EFFECT';

  IF (DECISION_VALUE = 'AUTO_BLOCK') THEN

    STEP_VALUE := 'INSERT_CARD_ACTION_QUEUE';

    ACTION_ID_VALUE := UUID_STRING();

    INSERT INTO APP.CARD_ACTION_QUEUE (
      action_id,
      transaction_id,
      customer_id,
      action_type,
      action_reason,
      priority,
      decision_confidence,
      pattern_matched,
      raw_decision
    )
    SELECT
      :ACTION_ID_VALUE,
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      'BLOCK_CARD',
      :JUSTIFICATION_VALUE,
      'FRAUD-HIGH',
      :CONFIDENCE_VALUE,
      :PATTERN_VALUE,
      :DECISION_JSON;

    ACTION_RESULT := OBJECT_CONSTRUCT(
      'status', 'QUEUED',
      'action_id', ACTION_ID_VALUE,
      'transaction_id', TRANSACTION_ID,
      'action_type', 'BLOCK_CARD'
    );

  ELSEIF (DECISION_VALUE = 'ESCALATE') THEN

    STEP_VALUE := 'INSERT_SLACK_OUTBOX';

    MESSAGE_ID_VALUE := UUID_STRING();

    MESSAGE_TEXT_VALUE :=
      'Fraud triage escalation for transaction '
      || TRANSACTION_ID
      || '. Customer: '
      || COALESCE(CUSTOMER_ID_VALUE, 'UNKNOWN')
      || '. Pattern: '
      || COALESCE(PATTERN_VALUE, 'UNKNOWN')
      || '. Confidence: '
      || COALESCE(TO_VARCHAR(CONFIDENCE_VALUE), 'UNKNOWN')
      || '. Reason: '
      || COALESCE(JUSTIFICATION_VALUE, '');

    MESSAGE_PAYLOAD_VALUE := OBJECT_CONSTRUCT(
      'channel', '#fraud-triage',
      'text', MESSAGE_TEXT_VALUE,
      'transaction_id', TRANSACTION_ID,
      'customer_id', CUSTOMER_ID_VALUE,
      'confidence', CONFIDENCE_VALUE,
      'pattern_matched', PATTERN_VALUE,
      'raw_decision', DECISION_JSON
    );

    INSERT INTO APP.SLACK_OUTBOX (
      message_id,
      transaction_id,
      customer_id,
      channel_name,
      message_payload,
      message_text,
      status
    )
    SELECT
      :MESSAGE_ID_VALUE,
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      '#fraud-triage',
      :MESSAGE_PAYLOAD_VALUE,
      :MESSAGE_TEXT_VALUE,
      'PENDING';

    ACTION_RESULT := OBJECT_CONSTRUCT(
      'status', 'QUEUED',
      'message_id', MESSAGE_ID_VALUE,
      'transaction_id', TRANSACTION_ID,
      'action_type', 'SLACK_ESCALATION'
    );

  ELSE

    STEP_VALUE := 'DISMISS_NO_OP';

    ACTION_RESULT := OBJECT_CONSTRUCT(
      'status', 'NO_OP',
      'transaction_id', TRANSACTION_ID,
      'decision', 'DISMISS'
    );

  END IF;

  STEP_VALUE := 'RETURN_SUCCESS';

  RETURN OBJECT_CONSTRUCT(
    'status', 'OK',
    'transaction_id', TRANSACTION_ID,
    'decision', DECISION_VALUE,
    'confidence', CONFIDENCE_VALUE,
    'pattern_matched', PATTERN_VALUE,
    'action_result', ACTION_RESULT
  );

EXCEPTION
  WHEN OTHER THEN

    ERROR_MESSAGE_VALUE := SQLERRM;
    ERROR_CODE_VALUE := SQLCODE;
    ERROR_STATE_VALUE := SQLSTATE;

    INSERT INTO APP.AGENT_ERRORS (
      transaction_id,
      customer_id,
      error_stage,
      error_message,
      raw_agent_output,
      raw_payload
    )
    SELECT
      :TRANSACTION_ID,
      :CUSTOMER_ID_VALUE,
      'PROCEDURE_EXCEPTION',
      :ERROR_MESSAGE_VALUE,
      :AGENT_OUTPUT_TEXT,
      OBJECT_CONSTRUCT(
        'failed_step', :STEP_VALUE,
        'sqlcode', :ERROR_CODE_VALUE,
        'sqlstate', :ERROR_STATE_VALUE,
        'agent_input', :AGENT_INPUT,
        'tool_trace', :TOOL_TRACE,
        'model_name', :MODEL_NAME
      )
    FROM TABLE(GENERATOR(ROWCOUNT => 1));

    RETURN OBJECT_CONSTRUCT(
      'status', 'ERROR',
      'error_stage', 'PROCEDURE_EXCEPTION',
      'failed_step', STEP_VALUE,
      'sqlcode', ERROR_CODE_VALUE,
      'sqlstate', ERROR_STATE_VALUE,
      'message', ERROR_MESSAGE_VALUE,
      'transaction_id', TRANSACTION_ID
    );

END;
$$;



-- ======================================================================================
-- 16._FRAUD_DB;-- 16. RUNTIME GRANTS FOR FRAUD_AGENT_RUNNER

GRANT USAGE ON SCHEMA APP TO ROLE FRAUD_AGENT_RUNNER;

GRANT SELECT, INSERT, UPDATE ON TABLE APP.CARD_ACTION_QUEUE TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT, INSERT, UPDATE ON TABLE APP.SLACK_OUTBOX TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT, INSERT ON TABLE APP.AGENT_DECISIONS TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT, INSERT ON TABLE APP.AGENT_ERRORS TO ROLE FRAUD_AGENT_RUNNER;

GRANT USAGE ON PROCEDURE APP.BLOCK_CARD(STRING, STRING, STRING, NUMBER, STRING, VARIANT) TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON PROCEDURE APP.ESCALATE_TO_SLACK(STRING, STRING, NUMBER, STRING, STRING, VARIANT) TO ROLE FRAUD_AGENT_RUNNER;

GRANT USAGE ON PROCEDURE APP.PERSIST_AGENT_DECISION(
  STRING,
  VARIANT,
  STRING,
  VARIANT,
  STRING,
  TIMESTAMP_NTZ
) TO ROLE FRAUD_AGENT_RUNNER;

USE ROLE ACCOUNTADMIN;


--testing the stored procedures manually 
USE ROLE FRAUD_AGENT_RUNNER;USE ROLE FRAUD MERIDIAN_FRAUD_DB;

CALL APP.BLOCK_CARD(
  'TXN_TEST_BLOCK',
  'CUST_TEST',
  'Unit test block action',
  95,
  'P-001',
  PARSE_JSON('{
    "decision": "AUTO_BLOCK",
    "confidence": 95,
    "pattern_matched": "P-001",
    "justification": "Unit test.",
    "tools_used": ["unit_test"]
  }')
);

USE WAREHOUSE FRAUD_WH;


SELECT *
FROM APP.CARD_ACTION_QUEUE
WHERE transaction_id = 'TXN_TEST_BLOCK';

--test escalate to slack
USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

CALL APP.ESCALATE_TO_SLACK(
  'TXN_TEST_ESCALATE',
  'CUST_TEST',
  82,
  'P-004',
  'Unit test escalation for Slack outbox. This verifies that ESCALATE decisions write a Slack-compatible payload to APP.SLACK_OUTBOX.',
  PARSE_JSON($$
  {
    "decision": "ESCALATE",
    "confidence": 82,
    "pattern_matched": "P-004",
    "justification": "Unit test escalation for Slack outbox.",
    "tools_used": [
      "unit_test"
    ]
  }
  $$)
);

SELECT *
FROM APP.SLACK_OUTBOX
WHERE transaction_id = 'TXN_TEST_ESCALATE';

SELECT
  message_id,
  transaction_id,
  customer_id,
  channel_name,
  status,
  message_text,
  message_payload,
  created_at
FROM APP.SLACK_OUTBOX
WHERE transaction_id = 'TXN_TEST_ESCALATE'
ORDER BY created_at DESC;

SELECT
  transaction_id,
  customer_id,
  channel_name,
  status,
  LEFT(message_text, 500) AS message_preview,
  created_at
FROM APP.SLACK_OUTBOX
WHERE transaction_id = 'TXN_TEST_ESCALATE'
ORDER BY created_at DESC;


USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;


--Test Valid AUTO_BLOCK Decision

USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

CALL APP.PERSIST_AGENT_DECISION(
  'TXN20260511104',

  PARSE_JSON($$
  {
    "source": "unit_test",
    "test_case": "valid_auto_block",
    "transaction_id": "TXN20260511104"
  }
  $$),

  $$
  {
    "decision": "AUTO_BLOCK",
    "confidence": 98,
    "pattern_matched": "P-001",
    "justification": "Large USD 1247.50 transaction followed four small online test charges at the same high-risk digital-goods merchant within minutes. This matches P-001 card testing followed by bust-out.",
    "tools_used": [
      "transaction_history_analyst",
      "fraud_pattern_search",
      "block_card"
    ]
  }
  $$,

  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "transaction_history_analyst",
        "status": "ok",
        "summary": "Retrieved CUST006 burst transactions and velocity features."
      },
      {
        "tool": "fraud_pattern_search",
        "status": "ok",
        "summary": "Matched P-001 card testing followed by bust-out."
      },
      {
        "tool": "block_card",
        "status": "queued"
      }
    ]
  }
  $$),

  'unit-test-model',
  DATEADD('second', -3, CURRENT_TIMESTAMP())
);


SELECT
  transaction_id,
  customer_id,
  merchant_id,
  decision,
  confidence,
  pattern_matched,
  justification,
  tools_used,
  model_name,
  run_completed_at
FROM APP.AGENT_DECISIONS
WHERE transaction_id = 'TXN20260511104'
ORDER BY run_completed_at DESC;

--Test A — ESCALATE path
-- This should write:

-- one row to APP.AGENT_DECISIONS
-- one row to APP.SLACK_OUTBOX

USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

CALL APP.PERSIST_AGENT_DECISION(
  'TXN20260511500',

  PARSE_JSON($$
  {
    "source": "unit_test",
    "test_case": "valid_escalate",
    "transaction_id": "TXN20260511500"
  }
  $$),

  $$
  {
    "decision": "ESCALATE",
    "confidence": 82,
    "pattern_matched": "P-004",
    "justification": "Round-number USD 2000 transaction to a crypto merchant matches P-004 scam-victim risk. Device and IP evidence do not strongly indicate stolen credentials, and P-004 recommends human outreach instead of auto-decline.",
    "tools_used": [
      "transaction_history_analyst",
      "fraud_pattern_search",
      "escalate_to_slack"
    ]
  }
  $$,

  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "transaction_history_analyst",
        "status": "ok",
        "summary": "Retrieved crypto transaction and merchant profile."
      },
      {
        "tool": "fraud_pattern_search",
        "status": "ok",
        "summary": "Matched P-004 crypto scam-victim guidance."
      },
      {
        "tool": "escalate_to_slack",
        "status": "queued"
      }
    ]
  }
  $$),

  'unit-test-model',
  DATEADD('second', -4, CURRENT_TIMESTAMP())
);

SELECT
  transaction_id,
  decision,
  confidence,
  pattern_matched,
  justification,
  tools_used,
  model_name,
  run_completed_at
FROM APP.AGENT_DECISIONS
WHERE transaction_id = 'TXN20260511500'
ORDER BY run_completed_at DESC;

SELECT
  transaction_id,
  customer_id,
  channel_name,
  status,
  LEFT(message_text, 500) AS message_preview,
  created_at
FROM APP.SLACK_OUTBOX
WHERE transaction_id = 'TXN20260511500'
ORDER BY created_at DESC;

-- Test B — DISMISS path
-- This should write:

-- one row to APP.AGENT_DECISIONS
-- no row to APP.CARD_ACTION_QUEUE
-- no row to APP.SLACK_OUTBOX

CALL APP.PERSIST_AGENT_DECISION(
  'TXN20260511300',

  PARSE_JSON($$
  {
    "source": "unit_test",
    "test_case": "valid_dismiss",
    "transaction_id": "TXN20260511300"
  }
  $$),

  $$
  {
    "decision": "DISMISS",
    "confidence": 88,
    "pattern_matched": "P-005",
    "justification": "Card-present Japan transaction appears consistent with travel context and P-005 frequent-traveler suppression. No separate strong account-takeover or card-testing evidence was found.",
    "tools_used": [
      "transaction_history_analyst",
      "fraud_pattern_search"
    ]
  }
  $$,

  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "transaction_history_analyst",
        "status": "ok",
        "summary": "Retrieved CUST007 travel context."
      },
      {
        "tool": "fraud_pattern_search",
        "status": "ok",
        "summary": "Applied P-005 frequent traveler suppression."
      }
    ]
  }
  $$),

  'unit-test-model',
  DATEADD('second', -2, CURRENT_TIMESTAMP())
);

SELECT
  transaction_id,
  decision,
  confidence,
  pattern_matched,
  justification,
  tools_used,
  model_name,
  run_completed_at
FROM APP.AGENT_DECISIONS
WHERE transaction_id = 'TXN20260511300'
ORDER BY run_completed_at DESC;

SELECT COUNT(*) AS card_action_rows
FROM APP.CARD_ACTION_QUEUE
WHERE transaction_id = 'TXN20260511300';

SELECT COUNT(*) AS slack_outbox_rows
FROM APP.SLACK_OUTBOX
WHERE transaction_id = 'TXN20260511300';


-- Test C — Safety override
-- This sends AUTO_BLOCK with confidence 85.

CALL APP.PERSIST_AGENT_DECISION(
  'TXN20260511103',

  PARSE_JSON($$
  {
    "source": "unit_test",
    "test_case": "safety_override_auto_block_below_90",
    "transaction_id": "TXN20260511103"
  }
  $$),

  $$
  {
    "decision": "AUTO_BLOCK",
    "confidence": 85,
    "pattern_matched": "P-001",
    "justification": "Multiple micro-charges indicate possible card testing, but confidence is below the permitted auto-block threshold.",
    "tools_used": [
      "transaction_history_analyst",
      "fraud_pattern_search",
      "block_card"
    ]
  }
  $$,

  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "transaction_history_analyst",
        "status": "ok"
      },
      {
        "tool": "fraud_pattern_search",
        "status": "ok"
      }
    ]
  }
  $$),

  'unit-test-model',
  DATEADD('second', -3, CURRENT_TIMESTAMP())
);

SELECT
  transaction_id,
  decision,
  confidence,
  pattern_matched,
  justification,
  tools_used,
  model_name,
  run_completed_at
FROM APP.AGENT_DECISIONS
WHERE transaction_id = 'TXN20260511103'
ORDER BY run_completed_at DESC;

SELECT COUNT(*) AS card_action_rows
FROM APP.CARD_ACTION_QUEUE
WHERE transaction_id = 'TXN20260511103';

SELECT
  transaction_id,
  customer_id,
  status,
  LEFT(message_text, 500) AS message_preview,
  created_at
FROM APP.SLACK_OUTBOX
WHERE transaction_id = 'TXN20260511103'
ORDER BY created_at DESC;

-- Test D — Invalid JSON
-- This confirms bad model output gets logged.

CALL APP.PERSIST_AGENT_DECISION(
  'TXN20260511104',

  PARSE_JSON($$
  {
    "source": "unit_test",
    "test_case": "invalid_json",
    "transaction_id": "TXN20260511104"
  }
  $$),

  'this is not valid json',

  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "unit_test",
        "status": "invalid_json_expected"
      }
    ]
  }
  $$),

  'unit-test-model-invalid',
  DATEADD('second', -1, CURRENT_TIMESTAMP())
);

SELECT
  transaction_id,
  customer_id,
  error_stage,
  error_message,
  raw_agent_output,
  raw_payload,
  created_at
FROM APP.AGENT_ERRORS
WHERE transaction_id = 'TXN20260511104'
ORDER BY created_at DESC
LIMIT 5;

--Final Unit Test Health Check

SELECT
  'AGENT_DECISIONS' AS object_name,
  COUNT(*) AS row_count
FROM APP.AGENT_DECISIONS
WHERE model_name LIKE 'unit-test%'

UNION ALL

SELECT
  'CARD_ACTION_QUEUE',
  COUNT(*)
FROM APP.CARD_ACTION_QUEUE
WHERE transaction_id IN ('TXN20260511104', 'TXN20260511103')

UNION ALL

SELECT
  'SLACK_OUTBOX',
  COUNT(*)
FROM APP.SLACK_OUTBOX
WHERE transaction_id IN ('TXN20260511500', 'TXN20260511103')

UNION ALL

SELECT
  'AGENT_ERRORS',
  COUNT(*)
FROM APP.AGENT_ERRORS
WHERE raw_payload:agent_input:source::STRING = 'unit_test'
   OR raw_payload:source::STRING = 'unit_test'
   OR raw_payload:model_name::STRING = 'unit-test-model-invalid';


SELECT
  transaction_id,
  decision,
  confidence,
  pattern_matched,
  model_name,
  run_started_at,
  run_completed_at,
  LEFT(justification, 200) AS justification_preview
FROM APP.AGENT_DECISIONS
WHERE model_name LIKE 'unit-test%'
ORDER BY run_completed_at DESC;

SELECT
  transaction_id,
  decision,
  pattern_matched,
  model_name,
  COUNT(*) AS row_count
FROM APP.AGENT_DECISIONS
WHERE model_name LIKE 'unit-test%'
GROUP BY
  transaction_id,
  decision,
  pattern_matched,
  model_name
ORDER BY
  transaction_id,
  decision;

  SELECT
  transaction_id,
  action_type,
  decision_confidence,
  pattern_matched,
  requested_at,
  LEFT(action_reason, 200) AS reason_preview
FROM APP.CARD_ACTION_QUEUE
WHERE transaction_id IN (
  'TXN20260511104',
  'TXN20260511103'
)
ORDER BY requested_at DESC;

SELECT
  transaction_id,
  status,
  created_at,
  LEFT(message_text, 300) AS message_preview
FROM APP.SLACK_OUTBOX
WHERE transaction_id IN (
  'TXN20260511500',
  'TXN20260511103'
)
ORDER BY created_at DESC;

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;

DELETE FROM APP.AGENT_DECISIONS
WHERE model_name LIKE 'unit-test%';

DELETE FROM APP.AGENT_ERRORS
WHERE raw_payload:agent_input:source::STRING = 'unit_test'
   OR raw_payload:source::STRING = 'unit_test'
   OR raw_agent_output = 'this is not valid json'
   OR raw_agent_output ILIKE '%Large USD 1247.50%'
   OR raw_agent_output ILIKE '%Round-number USD 2000%'
   OR raw_agent_output ILIKE '%Multiple micro-charges%'
   OR raw_agent_output ILIKE '%Card-present Japan transaction%';

DELETE FROM APP.CARD_ACTION_QUEUE
WHERE transaction_id IN (
  'TXN20260511104',
  'TXN20260511103',
  'TXN_TEST_BLOCK'
)
AND (
  action_reason ILIKE '%Large USD 1247.50%'
  OR action_reason ILIKE '%Safety override%'
  OR action_reason ILIKE '%Multiple micro-charges%'
  OR action_reason ILIKE '%Unit test%'
);

DELETE FROM APP.SLACK_OUTBOX
WHERE transaction_id IN (
  'TXN20260511500',
  'TXN20260511103',
  'TXN_TEST_ESCALATE'
)
AND (
  message_text ILIKE '%Round-number USD 2000%'
  OR message_text ILIKE '%Safety override%'
  OR message_text ILIKE '%Multiple micro-charges%'
  OR message_text ILIKE '%Unit test%'
);

SELECT
  'AGENT_DECISIONS_UNIT_TEST' AS object_name,
  COUNT(*) AS row_count
FROM APP.AGENT_DECISIONS
WHERE model_name LIKE 'unit-test%'

UNION ALL

SELECT
  'AGENT_ERRORS_UNIT_TEST',
  COUNT(*)
FROM APP.AGENT_ERRORS
WHERE raw_payload:agent_input:source::STRING = 'unit_test'
   OR raw_payload:source::STRING = 'unit_test'
   OR raw_agent_output = 'this is not valid json'

UNION ALL

SELECT
  'CARD_ACTION_QUEUE_TEST_RELATED',
  COUNT(*)
FROM APP.CARD_ACTION_QUEUE
WHERE transaction_id IN (
  'TXN20260511104',
  'TXN20260511103',
  'TXN_TEST_BLOCK'
)
AND (
  action_reason ILIKE '%Large USD 1247.50%'
  OR action_reason ILIKE '%Safety override%'
  OR action_reason ILIKE '%Multiple micro-charges%'
  OR action_reason ILIKE '%Unit test%'
)

UNION ALL

SELECT
  'SLACK_OUTBOX_TEST_RELATED',
  COUNT(*)
FROM APP.SLACK_OUTBOX
WHERE transaction_id IN (
  'TXN20260511500',
  'TXN20260511103',
  'TXN_TEST_ESCALATE'
)
AND (
  message_text ILIKE '%Round-number USD 2000%'
  OR message_text ILIKE '%Safety override%'
  OR message_text ILIKE '%Multiple micro-charges%'
  OR message_text ILIKE '%Unit test%'
);


TRUNCATE TABLE APP.AGENT_DECISIONS;
TRUNCATE TABLE APP.AGENT_ERRORS;
TRUNCATE TABLE APP.CARD_ACTION_QUEUE;
TRUNCATE TABLE APP.SLACK_OUTBOX;


--verify everything is clean
SELECT
  'AGENT_DECISIONS' AS object_name,
  COUNT(*) AS row_count
FROM APP.AGENT_DECISIONS

UNION ALL

SELECT
  'AGENT_ERRORS',
  COUNT(*)
FROM APP.AGENT_ERRORS

UNION ALL

SELECT
  'CARD_ACTION_QUEUE',
  COUNT(*)
FROM APP.CARD_ACTION_QUEUE

UNION ALL

SELECT
  'SLACK_OUTBOX',
  COUNT(*)
FROM APP.SLACK_OUTBOX;

--Grant Agent-Related Privileges
USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;

-- Cortex usage for the runtime role.
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE FRAUD_AGENT_RUNNER;

-- Some accounts also expose a more specific agent role.
-- If this fails, it is okay; continue with CORTEX_USER.
-- GRANT DATABASE ROLE SNOWFLAKE.CORTEX_AGENT_USER TO ROLE FRAUD_AGENT_RUNNER;

-- General object usage.
GRANT USAGE ON WAREHOUSE FRAUD_WH TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON DATABASE MERIDIAN_FRAUD_DB TO ROLE FRAUD_AGENT_RUNNER;

GRANT USAGE ON SCHEMA RAW TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA REF TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA FEATURES TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA KNOWLEDGE TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA SEMANTIC TO ROLE FRAUD_AGENT_RUNNER;
GRANT USAGE ON SCHEMA APP TO ROLE FRAUD_AGENT_RUNNER;

-- Allow creating an agent in APP schema if your account enforces this privilege.
GRANT CREATE AGENT ON SCHEMA APP TO ROLE FRAUD_AGENT_RUNNER;

-- Structured data access.
GRANT SELECT ON DYNAMIC TABLE FEATURES.TRIAGE_QUEUE_DT TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT ON DYNAMIC TABLE FEATURES.ENRICHED_TRANSACTIONS_DT TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT ON DYNAMIC TABLE FEATURES.CUSTOMER_VELOCITY_DT TO ROLE FRAUD_AGENT_RUNNER;

GRANT SELECT ON TABLE REF.CUSTOMERS TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT ON TABLE REF.MERCHANTS TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT ON TABLE REF.HISTORICAL_FRAUD_CASES TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT ON TABLE RAW.RAW_TRANSACTIONS TO ROLE FRAUD_AGENT_RUNNER;

-- Cortex Search access.
GRANT USAGE ON CORTEX SEARCH SERVICE KNOWLEDGE.FRAUD_PATTERN_SEARCH_SERVICE TO ROLE FRAUD_AGENT_RUNNER;

-- Semantic model stage access.
GRANT READ ON STAGE SEMANTIC.MODEL_STAGE TO ROLE FRAUD_AGENT_RUNNER;

-- App tables.
GRANT SELECT, INSERT, UPDATE ON TABLE APP.CARD_ACTION_QUEUE TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT, INSERT, UPDATE ON TABLE APP.SLACK_OUTBOX TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT, INSERT ON TABLE APP.AGENT_DECISIONS TO ROLE FRAUD_AGENT_RUNNER;
GRANT SELECT, INSERT ON TABLE APP.AGENT_ERRORS TO ROLE FRAUD_AGENT_RUNNER;

-- Stored procedures used as generic tools.
GRANT USAGE ON PROCEDURE APP.BLOCK_CARD(
  STRING,
  STRING,
  STRING,
  NUMBER,
  STRING,
  VARIANT
) TO ROLE FRAUD_AGENT_RUNNER;

GRANT USAGE ON PROCEDURE APP.ESCALATE_TO_SLACK(
  STRING,
  STRING,
  NUMBER,
  STRING,
  STRING,
  VARIANT
) TO ROLE FRAUD_AGENT_RUNNER;

GRANT USAGE ON PROCEDURE APP.PERSIST_AGENT_DECISION(
  STRING,
  VARIANT,
  STRING,
  VARIANT,
  STRING,
  TIMESTAMP_NTZ
) TO ROLE FRAUD_AGENT_RUNNER;

--Test Runner Role Access Again
USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;

SELECT CURRENT_ROLE() AS current_role;

SELECT COUNT(*) AS triage_count
FROM FEATURES.TRIAGE_QUEUE_DT;

SELECT COUNT(*) AS pattern_doc_count
FROM KNOWLEDGE.FRAUD_PATTERN_DOCS;

LIST @SEMANTIC.MODEL_STAGE;

-- ======================================================================================
-- 18. CORTEX AGENT
-- ======================================================================================
-- Creates the Meridian fraud triage Cortex Agent.
-- The YAML specification is also saved separately as agent_spec.yaml.

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

CREATE OR REPLACE AGENT APP.MERIDIAN_FRAUD_TRIAGE_AGENT
COMMENT = 'Meridian Bank fraud triage Cortex Agent'
PROFILE = '{"display_name": "Meridian Fraud Triage Agent", "avatar": "shield", "color": "red"}'
FROM SPECIFICATION $$
models:
  orchestration: claude-4-sonnet

orchestration:
  budget:
    seconds: 30
    tokens: 8000

tools:
  - tool_spec:
      type: "cortex_search"
      name: "fraud_pattern_search"
      description: >
        Search Meridian Bank fraud playbooks P-001 through P-005 to identify
        which internal fraud pattern best matches a suspicious transaction.

tool_resources:
  fraud_pattern_search:
    name: "MERIDIAN_FRAUD_DB.KNOWLEDGE.FRAUD_PATTERN_SEARCH_SERVICE"
    max_results: 5

instructions:
  system: >
    You are the Meridian Bank fraud triage agent. Your job is to analyze
    suspicious transaction descriptions and decide whether to AUTO_BLOCK,
    ESCALATE, or DISMISS. Use the fraud_pattern_search tool to look up known
    fraud patterns and match them against the transaction details provided.

  response: >
    Always respond with a single valid JSON object containing these fields:
    decision, confidence, pattern_matched, justification, and tools_used.
    The decision must be one of AUTO_BLOCK, ESCALATE, or DISMISS.
    The confidence must be an integer from 0 to 100.
    The pattern_matched value must be one of P-001, P-002, P-003, P-004, P-005, or NONE.
    Do not include markdown, code fences, or any text outside the JSON object.

  orchestration: >
    Always use fraud_pattern_search before deciding.
    Be conservative. AUTO_BLOCK is allowed only when confidence is at least 90.
    If confidence is below 90, choose ESCALATE instead.
    For geographic anomaly cases, apply P-005 frequent-traveler suppression before escalating or blocking.
    For P-004 crypto scam-victim cases, prefer ESCALATE rather than AUTO_BLOCK unless there is separate strong account-takeover or stolen-card evidence.
$$;

GRANT USAGE ON AGENT APP.MERIDIAN_FRAUD_TRIAGE_AGENT TO ROLE FRAUD_AGENT_RUNNER;

SHOW AGENTS IN SCHEMA APP;

USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

SELECT SNOWFLAKE.CORTEX.DATA_AGENT_RUN(
  'MERIDIAN_FRAUD_DB.APP.MERIDIAN_FRAUD_TRIAGE_AGENT',
  $$
  {
    "messages": [
      {
        "role": "user",
        "content": [
          {
            "type": "text",
            "text": "A customer had four small online card-not-present transactions of 1.99, 2.99, 4.99, and 9.99 at a high-risk digital-goods merchant, followed within minutes by a 1247.50 transaction at the same merchant from a new device. Which fraud pattern applies? Return only JSON."
          }
        ]
      }
    ],
    "stream": false,
    "tool_choice": {
      "type": "auto"
    }
  }
  $$
) AS agent_response;