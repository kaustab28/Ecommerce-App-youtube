# Meridian Bank Agentic Fraud Triage System

## 1. Architecture Analyst Triage Baseline## 1. Architecture Overview

| Transaction ID | Manual Verdict | Pattern | Confidence | Reasoning |
|---|---|---:|---:|---|
| TXN20260511100 | ESCALATE | P-001 | 82 | First micro-charge at high-risk digital-goods merchant from unknown proxy-like device/IP. |
| TXN20260511101 | ESCALATE | P-001 | 85 | Second micro-charge within minutes, same customer, merchant, device, and IP country. |
| TXN20260511102 | ESCALATE | P-001 | 88 | Third micro-charge within P-001 window. Meets count signal but no large bust-out visible yet. |
| TXN20260511103 | ESCALATE | P-001 | 89 | Fourth micro-charge in same burst. Very suspicious but still below 90% auto-block threshold. |
| TXN20260511104 | AUTO_BLOCK | P-001 | 98 | Large bust-out transaction after four micro-charges in under 10 minutes. |
| TXN20260511200 | AUTO_BLOCK | P-003 | 94 | Unknown device, off-hours, high-value jewelry transaction, foreign merchant and IP indicators. |
| TXN20260511300 | DISMISS | P-005 | 88 | Card-present Tokyo cafe transaction with travel context and continuing device. |
| TXN20260511301 | DISMISS | P-005 | 87 | Follow-up travel/lodging-style transaction in same Japan context. |
| TXN20260511400 | AUTO_BLOCK | P-003 | 91 | Unknown Windows device, off-hours, high-value foreign jewelry/luxury transaction. |
| TXN20260511500 | ESCALATE | P-004 | 82 | Round-number crypto transaction; escalate for scam-victim review, do not auto-decline. |
| TXN20260511600 | ESCALATE | P-003 | 78 | New device, off-hours, high-risk gaming voucher merchant, but insufficient for auto-block. |

## 3. Architecture Design Decisions

### Milestone 1 Data Foundation

The system uses separate schemas for raw landing data, reference data, feature engineering, application/runtime objects, knowledge documents, and semantic-model artifacts. This separation keeps the pipeline easier to govern and debug.

Transactions first land in `RAW.RAW_TRANSACTIONS`. Customer, merchant, and historical fraud data are loaded into the `REF` schema. The `FEATURES.ENRICHED_TRANSACTIONS_DT` Dynamic Table joins transaction events to customer and merchant profiles. The `FEATURES.CUSTOMER_VELOCITY_DT` Dynamic Table computes rolling customer behavior features used to detect bursts, new devices, new merchants, travel signals, and crypto/money-transfer history.

The triage queue is implemented as `FEATURES.TRIAGE_QUEUE_DT`. It filters to transactions where `risk_score >= 70`, `initial_decision = 'REVIEW'`, and `authorization_status = 'PENDING_REVIEW'`. The queue contains exactly 11 transactions, matching the assignment test set.

Dynamic Table target lag is set to 1 minute so that enriched triage records become available quickly enough to support the 90-second processing requirement while keeping refresh frequency reasonable for the assignment scale.



## 4. Feature Engineering

TODO.

## 5. Cortex Search Design

The fraud-pattern markdown files are loaded into `KNOWLEDGE.FRAUD_PATTERN_DOCS`, with one row per playbook document. The Cortex Search service `KNOWLEDGE.FRAUD_PATTERN_SEARCH_SERVICE` indexes the playbook `content` column and exposes metadata including pattern ID, title, category, severity, and file name.

The search service was tested with three representative queries:
1. Card-testing and bust-out behavior returned P-001.
2. Geographic anomaly with travel evidence returned P-005 and P-002.
3. Round-number crypto scam behavior returned P-004.

These results confirm that the agent can retrieve the correct policy documents for the main fraud patterns in the test set.

## 6. Cortex Analyst Semantic Model

The semantic model `semantic_model.yaml` exposes three logical data surfaces:

1. `triage_queue` — enriched pending review transactions with velocity features.
2. `all_enriched_transactions` — complete enriched transaction history.
3. `historical_fraud_cases` — confirmed historical fraud examples.

Verified queries were added for:
- customer transaction history,
- single transaction inspection,
- card-testing burst detection,
- travel-suppression checks,
- historical fraud-case analogy lookup.

This semantic layer lets the future Cortex Agent ask business-level questions without manually writing SQL against raw physical table names.

TODO.

## 7. Cortex Agent Design

TODO.

## 8. Test Results

TODO: Fill after running the agent.

## 9. Evaluation

TODO.

## 10. Cost and Latency Notes

TODO.

## 11. Limitations and Future Work

### Cortex Agent Runtime Access Limitation

The Cortex Agent object `APP.MERIDIAN_FRAUD_TRIAGE_AGENT` was created successfully in Snowflake. The agent specification was accepted and the object appears in the `APP` schema.

However, live execution was blocked by Snowflake trial-account entitlement. Both Snowflake Intelligence preview and SQL invocation through `SNOWFLAKE.CORTEX.DATA_AGENT_RUN` returned:

```json
{
  "message": "Access denied for trial accounts.",
  "code": "399504"
}
TODO: Add architecture diagram and explanation.

