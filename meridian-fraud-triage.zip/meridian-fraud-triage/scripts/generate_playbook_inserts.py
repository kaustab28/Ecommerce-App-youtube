from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATTERN_DIR = ROOT / "fraud_patterns"
OUT_FILE = ROOT / "generated_playbook_inserts.sql"

FILES = [
    ("P-001", "P001_card_testing_bustout.md", "Card Testing Followed by Bust-Out", "Card-Not-Present Fraud", "HIGH"),
    ("P-002", "P002_geographic_anomaly.md", "Geographic Anomaly / Impossible Travel", "Counterfeit / Cloned Card Fraud", "HIGH"),
    ("P-003", "P003_account_takeover.md", "Account Takeover", "Credential / Session Compromise", "HIGH"),
    ("P-004", "P004_crypto_scam.md", "Authorized Push Payment to Crypto", "Authorized Push Payment Fraud", "MEDIUM-HIGH"),
    ("P-005", "P005_frequent_traveler_suppression.md", "Frequent Traveler False Positive Suppression", "False-Positive Suppression Rule", "N/A"),
]

def sql_quote(value: str) -> str:
    return value.replace("'", "''")

statements = [
    "USE DATABASE MERIDIAN_FRAUD_DB;",
    "USE SCHEMA KNOWLEDGE;",
    "TRUNCATE TABLE KNOWLEDGE.FRAUD_PATTERN_DOCS;",
]

for pattern_id, file_name, title, category, severity in FILES:
    path = PATTERN_DIR / file_name
    content = path.read_text(encoding="utf-8")

    statements.append(f"""
INSERT INTO KNOWLEDGE.FRAUD_PATTERN_DOCS (
  pattern_id,
  file_name,
  title,
  category,
  severity,
  content
)
SELECT
  '{sql_quote(pattern_id)}',
  '{sql_quote(file_name)}',
  '{sql_quote(title)}',
  '{sql_quote(category)}',
  '{sql_quote(severity)}',
  $$ {content} $$;
""".strip())

OUT_FILE.write_text("\n\n".join(statements), encoding="utf-8")

print(f"Wrote {OUT_FILE}")