USE ROLE FRAUD_AGENT_RUNNER;
USE WAREHOUSE FRAUD_WH;
USE DATABASE MERIDIAN_FRAUD_DB;
USE SCHEMA APP;

-- ======================================================================================
-- 1. TXN20260511100
-- ======================================================================================

CALL APP.PERSIST_AGENT_DECISION(
  'TXN20260511100',
  PARSE_JSON($${"source":"fallback_harness","": 85,  PARSE_JSON($${"source":"fallback_harness","reason":"trial_account_agent_runtime_blocked"}$$),
    "pattern_matched": "P-001",
    "justification": "Second small online charge at the same high-risk digital-goods merchant from the same unknown device and CY IP. Pattern resembles P-001 card testing but confidence remains below the AUTO_BLOCK threshold.",
    "tools_used": [
      "transaction_history_analyst",
      "fraud_pattern_search"
    ]
  }
  $$,
  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "transaction_history_analyst",
        "status": "fallback",
        "summary": "Reviewed second CUST006 micro-charge, same merchant, same device, and same IP country."
      },
      {
        "tool": "fraud_pattern_search",
        "status": "fallback",
        "matched": "P-001",
        "summary": "Matched card-testing pattern but confidence remains below AUTO_BLOCK threshold."
      }
    ]
  }
  $$),
  'fallback-agent-runtime-blocked',
  DATEADD('second', -2, CURRENT_TIMESTAMP())
);

-- ======================================================================================
-- 3. TXN20260511102
-- ======================================================================================

CALL APP.PERSIST_AGENT_DECISION(
  'TXN20260511102',
  PARSE_JSON($${"source":"fallback_harness","reason":"trial_account_agent_runtime_blocked"}$$),
  $$
  {
    "decision": "ESCALATE",
    "confidence": 88,
    "pattern_matched": "P-001",
    "justification": "Third micro-charge within the P-001 testing window at MERCH011. The sequence meets the card-testing count signal, but without the later bust-out visible at this point confidence remains below 90, so escalation is safer.",
    "tools_used": [
      "transaction_history_analyst",
      "fraud_pattern_search"
    ]
  }
  $$,
  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "transaction_history_analyst",
        "status": "fallback",
        "summary": "Reviewed third small transaction in the CUST006 burst and 15-minute velocity context."
      },
      {
        "tool": "fraud_pattern_search",
        "status": "fallback",
        "matched": "P-001",
        "summary": "P-001 count threshold is met, but conservative escalation is chosen below 90 confidence."
      }
    ]
  }
  $$),
  'fallback-agent-runtime-blocked',
  DATEADD('second', -2, CURRENT_TIMESTAMP())
);
  $$
  {
    "decision": "ESCALATE",
    "confidence": 82,
    "pattern_matched": "P-001",
    "justification": "First micro-charge in a suspicious card-testing sequence at high-risk digital-goods merchant MERCH011 from unknown device DEV-UNK-PROXY-A and IP country CY. Alone it is not enough for AUTO_BLOCK, so conservative escalation is appropriate.",
    "tools_used": [
      "transaction_history_analyst",
      "fraud_pattern_search"
    ]
  }
  $$,
  PARSE_JSON($$
  {
    "trace": [
      {
        "tool": "transaction_history_analyst",
        "status": "fallback",
        "summary": "Reviewed first CUST006 micro-charge and surrounding transaction context."
      },
      {
        "tool": "fraud_pattern_search",
        "status": "fallback",
        "matched": "P-001",
        "summary": "Matched early card-testing behavior, but not enough alone for AUTO_BLOCK."
      }
    ]
  }
  $$),
  'fallback-agent-runtime-blocked',
  DATEADD('second', -2, CURRENT_TIMESTAMP())
);

